## Running
The easiest way to run this demo is to use a Python or nodejs one-line server:

    $ python -m SimpleHTTPServer -p 8080

or, with nodejs

    npm install -g http-server; http-server

Then just open up a browser and go to http://localhost:8080
