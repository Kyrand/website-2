/* global $, _, crossfilter, d3  */
(function(verify,  _, $) {
    'use strict';
    
    
}(window.verify = window.verify || {}, _, $));
