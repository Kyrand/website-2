from verify_utils import *
import config as cf
import numpy as np
import ipdb

class Verifier(object):
    
    def __init__(self, date, rule_groups=cf.NOVERIFY_RULES, company_cols=cf.COMPANY_COLS, fuzzy_flag=False, items=None, weights_flag=True, **kw):
        self.date = date
        self.company_cols = company_cols
        self.fuzzy_flag = fuzzy_flag
        self.weights_flag = weights_flag
        self.valid_items = items or cf.VALID_ITEMS
        #print self.valid_items
        self.timestamp = pd.Timestamp(date)
        self.valid_rule_sets = []
        self.invalid_rule_sets = []
        self.rule_item_groups = {}
        self.df_rules, self.df_items = get_dframes_rules()
        self.df_data = get_dframes_data(**kw)
        # self.df_data = get_rawdata()
        self.all_rule_sets = get_possible_rules(rule_groups)
        
        self.group_items = self.get_group_items()
        self.get_group_items()
        self.set_valid_rules()
        self.pass_ids = []
        self.stats = {}


    def add_fuzzy_items(self):

        self.fuzzy_data = pd.read_csv(cf.FUZZY_ITEMS_FNAME)
        
        
    def set_valid_rules(self):
        
        for rule_set in self.all_rule_sets:
            companies = test_rule_set(rule_set, self.timestamp)
            if companies:
                self.valid_rule_sets.append({'key':':'.join(rule_set), 'companies':companies, 'rules':rule_set})
                for rule in rule_set:
                    self.rule_item_groups[rule] = get_rule_item_groups(rule)
    
    #def get_rule_item_groups():
    #    for rule in self.all_rule_sets:
    def get_verify_ids(self):
        
        self.stats['verify'] = defaultdict(int)
        #pass_ids = set()
        pass_ids = []
        self.viable_rule_sets = []

        df_rule_set_scores = pd.DataFrame()
        df_rule_set_scores['ids'] = self.df_data.index
        df_rule_set_scores.set_index('ids', inplace=True)
        df_rule_set_scores['score'] = 0
        
        for rule_set in self.valid_rule_sets:
            logger.info('Testing rule-set ' + rule_set['key'])
            # rule_set -> {'companies': ['Company3'], 'key': u'AB1:C1:E1', 'rules':['AB1'...]}
            #rule_set_ids = set(self.df_data['Serial']) # all ids to start
            rule_set_ids = []
            
            df_rule_scores = pd.DataFrame()
            df_rule_scores['ids'] = self.df_data.index
            df_rule_scores.set_index('ids', inplace=True)
            df_rule_scores.fillna(0, inplace=True)
                
            for rule in rule_set['rules']:
                rule_pass_flag = True
                rule_ids = []
                # Need to make a 'score' dataframe for the item-groups
                item_groups = self.rule_item_groups[rule]
                
                df_igroup_scores = pd.DataFrame(columns=item_groups)
                df_igroup_scores['ids'] = self.df_data.index
                df_igroup_scores.set_index('ids', inplace=True)
                df_igroup_scores.fillna(0, inplace=True)
                
                for item_group in item_groups:
                    # Item-group -> 'AB1' -> {u'C', u'L', u'M'}
                    items = self.get_item_group_items(item_group, rule_set['companies'])
                    # if no items, rule fails
                    if not items:
                        rule_pass_flag = False
                        logger.info('Failed rule %s, item-group %s'%(rule, item_group))
                        break
                        
                    logger.debug('Items: ' + str(items))    
                    if not self.fuzzy_flag:
                        # Normal, deterministic pass
                        rule_ids.append(\
                                        self.df_data[(self.df_data[list(items)] > 0).any(axis=1)].index)
                    else:
                        if cf.DEPENDENT_VARIABLES:
                            df_igroup_scores[item_group] = self.df_data[list(items)].max(axis=1)
                        else:
                            df_igroup_scores[item_group] = 1 - (1 - self.df_data[list(items)].clip_upper(1)).product(axis=1)
                        # maximum value of 1 for any item-column
                        df_igroup_scores = df_igroup_scores.clip_upper(1)
                        # We're dealing with fuzzy variables
                        
                else:
                    #rule_pass_flag = True
                    #self.viable_rules.append()
                    logger.info('ITEMS IN EVERY ITEM-GROUP!!!')
                    #print rule_set_ids
                    if not self.fuzzy_flag:
                        ids = set.intersection(*[set(l) for l in rule_ids])
                        rule_set_ids.append(ids)
                    else:
                        rule_score = df_igroup_scores.product(axis=1)
                        # import ipdb; ipdb.set_trace()
                        df_rule_scores[rule] = rule_score
                        # df_rule_scores['score'] = np.maximum(rule_set_score, df_rule_set_scores['score'])
                
                if not rule_pass_flag:
                    break
                    #logger.info('FAILED RULE!')
            # Now assess the rule ('AB1', 'C1', 'E1') from its component scores
            else:
                if not self.fuzzy_flag:
                    self.viable_rule_sets.append(rule_set)
                    logger.info('EVERY RULE VIABLE IN RULE-SET ' + str(rule_set))
                    # Now we intersect the rule-ids of this rule-set, e.g. ids that have passed AB1, C1 and E1
                    ids = set.intersection(*rule_set_ids)
                    #print ids
                    logger.info('%s: %d passes'%(rule_set['key'], len(ids)))
                    pass_ids.append(ids)
                else:
                    rule_set_score = df_rule_scores.product(axis=1)
                    df_rule_set_scores['score'] = np.maximum(rule_set_score, df_rule_set_scores['score'])
                    
                
        logger.info('Number of passed rule-sets: ' + str(len(pass_ids)))
        
        df = self.df_data_verify = self.df_data
        if pass_ids and not self.fuzzy_flag:
            self.pass_ids = set.union(*pass_ids)
            df['verify'] = False
            df['verify'].loc[self.pass_ids] = True
        else:
            df['verify'] = df_rule_set_scores['score']

        # if self.weights_flag:
        #     self.apply_weights()
            
        #print ids
        #print len(ids)                    
                    
    def get_group_items(self):
        
        df_items_code = self.df_items.drop_duplicates([cf.CODE_COLUMN])
        df_items_code = df_items_code.set_index(cf.CODE_COLUMN)

        group_items = defaultdict(dict)

        for group in cf.ITEM_GROUPS:
            gp = df_items_code.groupby(group)
            for k, rows in gp.groups.items():
                for r in rows: 
                    if r not in self.valid_items:
                        continue
                    #print r
                    companies = df_items_code.loc[r][cf.COMPANY_COLS[0]:cf.COMPANY_COLS[-1]]

                    for c in companies.iteritems():
                        #print c
                        # should be tuple of form ('Company 1', <date>)
                        if not pd.isnull(c[1]):
                            # if row-company is time-stamped:
                            ct = group_items[k].setdefault(c[0], [])
                            ct.append({'item':r, 'date':c[1]})

        return group_items

            
    def get_item_group_items(self, igroup, companies):
        
        logger.info('Testing group %s with companies %s'%(igroup, str(companies)))
        valid_items = set()
        # 'C' -> {u'Company1': ['item':u'GBDrLic': 'date':Timestamp('2015-12-09 00:00:00')],...
        igroup_items_by_comp = self.group_items[igroup]
        for c in companies:
            items = igroup_items_by_comp.get(c, [])
            for item in items:
                if item['date'] <= self.timestamp:
                    #logger.info('Adding %s to group %s'%(item, igroup))
                    valid_items.add(item['item'])
        logger.info('Valid items: ' + str(valid_items))            
        return valid_items
    
        
    def get_weight_df_score(self, df):
        total_score = ((df['verify'] * df.INDWGT * df.InternetUse).sum()) / (df.INDWGT*df.InternetUse).sum()
        return total_score
    
    def get_dem_stats(self, groups=cf.DEMOGRAPHIC_GROUPS):
        
        data = []
        df = self.df_data_verify        

        total_score = float(df['verify'].sum())/len(df.index)
        
        if self.weights_flag:
            total_score = self.get_weight_df_score(df)
         
        data.append({'date': self.timestamp, 'group':'ALL_VERIFY', 'subgroup':1,
                     'value': round(100.0 * total_score, 2)})
        
        for group in groups:
            # Get percentage pass-rates, round to nearest 2 decimal points. 
            # gps = df.groupby(group).apply(\
            #     lambda x: round(100*float(len(x[x['verify'] == True].index))/len(x.index),2))
            
            gps = df.groupby(group).apply(\
                                          #lambda x: round(100*float(x['verify'].sum())/len(x.index), 2))
                                          lambda x: round(100 * self.get_weight_df_score(x), 2))
            for subgroup in list(gps.iteritems()):
                data.append({'group':group, 'subgroup':subgroup[0], 'date':self.timestamp, 'value':subgroup[1]})
      
        return data

    def apply_weights(self):
        
        #df = self.df_data_verify['verify'] * self.df_data_verify['internet_weight']
        df = self.df_data_verify['verify']
        df = df * self.df_data_verify.norm_weight

        self.df_data_verify['verify'] = df
        
