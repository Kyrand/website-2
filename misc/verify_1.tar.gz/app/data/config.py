# -*- coding: utf-8 -*-
DEPENDENT_VARIABLES = False

RULE_ITEM_FNAME = 'data/verify_rules_clean.xlsx'
DATA_FNAME = 'data/ONS_aug_oct_removed.csv'
#DATA_FNAME = 'data/ONS_aug_oct.xls'
FUZZY_ITEMS_FNAME = 'data/fuzzy_items.csv'
VIZ_JSON_FNAME = 'verify_data.json'

DEMOGRAPHIC_GROUPS = ['AGEX', 'RSEX', 'URI', 'GrpInc', 'NSECAC3', 'DVILO4a', 'HHTypA', 'GorA', 'HighEd4'] # 'DVILO3a']

GROUP_LABELS = {'AGEX':
                {'1': '16-24', '2': '25-44', '3': '45-54', '4':'55-64', '5': '65-74', '6':'75+'},
                'RSEX': {'1': 'male', '2':'female'},
                'URI': {'1':'urban area', '2':'rural area'},
                'GrpInc': {'1':'< £10,399', '2': '£10,400-19,760', '3': '£19,760-28599', '4': '£28,600+', '97':'No income source', '98':'Refused to answer', '99':"Don't know"},
                'DVILO3a': {'1': 'Employed', '2': 'Unemployed', '3': 'Econ. inactive'},
                'NSECAC3': {'1':'Managerial and professional', '2':'Intermediate', '3':'Routine and manual', '4':'Not classified'},
                'HHType': {'1':'One person', '2':'Married with dept. child', '3':'Married no dept. child', '4':'Lone parent', '5':'All others'}
                }

A_RULES = [u'AB1', u'AB2', u'AB3', u'AB4', u'AB5', u'AB6', u'AB7', u'AB8', u'AB9', u'AB10', u'AB11']
C_RULES = [u'C1', u'C2', u'C3', u'C4', u'C5', u'C6']
E_RULES = [u'E1', u'E2']
Z_RULES = [u'Auth1']

VERIFY_RULES = [A_RULES, C_RULES, E_RULES, Z_RULES]
NOVERIFY_RULES = [A_RULES, C_RULES, E_RULES]
#NOVERIFY_RULES = [A_RULES, C_RULES]
FILTER_RULESETS = False

COMPANY_COLS = ['Company 1', 'Company 2', 'Company 3', 'Company 4', 'Company 5', 'Company 6', 'Company 7', 'Company 8']
#COMPANY_COLS = ['Company1']

VALID_ITEMS = ['GrpInc', 'UKPPort', 'GBDrLic', 'ROIPPort', 'EUPPort', 'NonEUPP', 'UKBiP', 'UKASC', 'UKBAc', 'UKCCard', 'UKLoan', 'UKMort']#, 'SPhone'] 

#FUZZY_ITEMS = ['Mphonecon', 'MarrC', 'UKBAccredit', 'Tablet', 'BirthC', 'Sloan']
FUZZY_ITEMS = ['Mphonecon', 'MarrC', 'UKBAccredit', 'Tablet', 'BirthC', 'Sloan', 'Justgiving', 'Post', 'Bankdata', 'SPhone', 'InternetUse']
# ?? SPhone Bacccredit

ALL_ITEMS = VALID_ITEMS + FUZZY_ITEMS

ITEM_GROUPS = ['Item group 1', 'Item group 2', 'Item group 3', 'Item group 4']

CODE_COLUMN = 'Code'
