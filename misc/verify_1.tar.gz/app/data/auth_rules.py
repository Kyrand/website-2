import itertools
import pandas as pd
from collections import defaultdict
from operator import itemgetter

import logging
logger = logging.getLogger("__name__")
logger.setLevel(logging.INFO)


A_RULES = [u'AB1', u'AB2', u'AB3', u'AB4', u'AB5', u'AB6', u'AB7', u'AB8', u'AB9', u'AB10', u'AB11']
C_RULES = [u'C1', u'C2', u'C3', u'C4', u'C5', u'C6']
E_RULES = [u'E1', u'E2']
Z_RULES = [u'Auth1']

AUTH_RULES = [A_RULES, C_RULES, E_RULES, Z_RULES]
NOAUTH_RULES = [A_RULES, C_RULES, E_RULES]

COMPANY_COLS = ['Company1', 'Company2', 'Company3', 'Company4', 'Company5', 'Company6', 'Company7', 'Company8']
#COMPANY_COLS = ['Company1']

VALID_ITEMS = ['GrpInc', 'UKPPort', 'GBDrLic', 'ROIPPort', 'EUPPort', 'NonEUPP', 'UKBiP', 'UKASC', 'UKBAc', 'UKCCard', 'UKLoan', 'UKMort', 'SPhone'] 

    
def memoize(f):
    """ Memoization decorator for functions taking one or more arguments. """
    class memodict(dict):
        def __init__(self, f):
            self.f = f
        def __call__(self, *args):
            return self[args]
        def __missing__(self, key):
            ret = self[key] = self.f(*key)
            return ret
    return memodict(f)

    
def get_possible_rules(rules):
    return list(itertools.product(*rules))

    
def get_dframes(xlfname='auth_rules_clean.xlsx'):
    
    df_rules = pd.read_excel(xlfname, 'Rules')
    df_items = pd.read_excel(xlfname, 'Items')

    df_rules = df_rules.set_index('Rule code')
    
    return df_rules, df_items


def get_dummydata(fname='dummy_survey.json'):
    
    df_dummydata = pd.read_json(fname, orient='records')
    return df_dummydata

    
def get_rawdata(fname='raw_data.csv'):

    df_rawdata = pd.read_csv(fname)
    return df_rawdata

    
def test_company_cover(df_rule, timestamp, company_cols=COMPANY_COLS):

    companies = {}
    for col in company_cols:
        # Test for missing dates
        if df_rule[df_rule[col].isnull()].empty:
            # if no missing dates
            #print 'first pass with company ' + col
            #print df_rule[col].min()
            #print df_rule
            if df_rule[col].max() <= timestamp:
                companies[col] = True

    return companies
            

def test_rule_set(rule_set, timestamp, company_cols=COMPANY_COLS):
    
    df_rule = df_rules.loc[list(rule_set)]
    #companies = test_company_cover(df, timestamp, company_cols)
    
    companies = []
    for col in company_cols:
        # Test for missing dates
        if df_rule[df_rule[col].isnull()].empty:
            # if no missing dates
            #print 'first pass with company ' + col
            #print df_rule[col].min()
            #print df_rule
            if df_rule[col].max() <= timestamp:
                companies.append(col)
    #logger.info('Rule %s failed'%(str(rule)))
    return companies   
    
    
def get_dates():
    df_companies = df_rules.ix[:,'Company1':'Company8']
    vals = df_companies.values.flatten()
    vals = list(set(vals))
    # sort and remove first 'NaT' value
    vals.sort()
    return vals[1:]    



def get_rules_status_by_date(rules, timestamp, company_cols=COMPANY_COLS):
    """ For timestamped date, get all valid and invalid rules of form 
    AB1:C1:E1.
    """
    res = { 'invalid':[], 'valid':[] }
    
    
    for rule in rules:
        if not test_rule(rule, timestamp, company_cols):
            res['invalid'].append(rule)
        else:
            res['valid'].append(rule)
            
    return {'date': timestamp, 'rules': res}


def get_valid_rules_by_date(rules, cutoff_date, company_cols=COMPANY_COLS):
    """ Get timestamped valid and invalid rules of form AB1:C1:E1 
    rules -> all possible configurations of rule groups A, C, E (Auth)
    """
    key_dates = get_dates()
    if cutoff_date:
        key_dates = [d for d in key_dates if pd.Timestamp(d) < cutoff_date]
        
    rules_data = []
    for d in key_dates:
        timestamp = pd.Timestamp(d)
        rules_data.append(get_rules_status_by_date(rules, timestamp, company_cols))

    return rules_data


def get_rule_item_groups(rule):
    # get slice of rule-items
    ris = df_rules.loc[rule]['Item group 1':'Item group 4']
    return set(ris[ris.notnull()])
            

def get_group_items():

    df_items_code = df_items.drop_duplicates(['Code'])
    df_items_code = df_items_code.set_index('Code')

    group_items = defaultdict(dict)

    for group in ['Item-group-1', 'Item-group-2', 'Item-group-3', 'Item-group-4']:
        gp = df_items_code.groupby(group)
        for k, rows in gp.groups.items():
            for r in rows: 
                if r not in VALID_ITEMS:
                    continue
                #print r
                companies = df_items_code.loc[r]['Company1':'Company8']
                
                for c in companies.iteritems():
                    #print c
                    # should be tuple of form ('Company1', <date>)
                    if not pd.isnull(c[1]):
                        # if row-company is time-stamped:
                        ct = group_items[k].setdefault(c[0], [])
                        ct.append({'item':r, 'date':c[1]})
                
    return group_items

    
def get_valid_group_items():
    """ Filter existing set of group items by set available to dummy-data """
    group_items = get_group_items()
    
    dummy_items = [col for col in df_dummydata.columns.tolist() if col in VALID_ITEMS]
    
    valid_group_items = {}
    
    for code, items in group_items.items():
        
        valid_group_items[code] = [item for item in items if item in dummy_items]
        
    return valid_group_items
        



def get_group_ids():
    """ For each group get eligible dummy ids """
    group_ids = {}
    for group, items in group_items.items():
        # ids = df_dummydata[df_dummydata[items].any(1)]['Serial']
        ids = df_dummydata[(df_dummydata[items] > 0).any(axis=1)]['Serial']

        group_ids[group] = set(ids)
        
    return group_ids
    

@memoize
def get_rule_set_pass_ids(rule_set):
    pass_sets = []
    # for each rule, e.g. 'AB1', get all pass-ids 
    for rule in rule_set:
        # get all groups for rule, e.g. 'AB1' -> 'C', 'M', 'L' 
        rule_groups = get_rule_groups(rule)
        #valid_items = set()
        #print rule_groups
        all_ids = set()
        # for each rule group, e.g. 'C', get all pass-ids and update set
        # pass-ids derived from dummydata using valid items related to group
        for group in rule_groups:
            try:
                all_ids.update(group_ids[group])
            except KeyError:
                print '%s group has no documents in Items-sheet'%group

        # store the pass-ids for this rule     
        pass_sets.append(all_ids)
        
    logger.info('%s: %s'%(str(rule_set), str([len(ps) for ps in pass_sets])))
    # pass_sets are of form AB1->(3, 7, 16...), C->(2, 4, 5, ...) 
    # user must pass every rule in rule_set so we want to intersect these
    # id-sets
    all_pass_ids = set(df_dummydata['Serial']) # start with all the ids
    for ids in pass_sets:
        all_pass_ids.intersection_update(ids)
                
    logger.info('Number of pass ids: ' + str(len(all_pass_ids)))
    
    return all_pass_ids
    
    
def get_pass_ids_by_date(rule_data):
    """ Given rule_data of form [{'date':.., 'rules':{'invalid':[], 'valid':[]}}]
    return ids passing each rule by date.
    """
    # get rule data, list of valid and invalid by date
    #rule_data = get_rule_data()
    
    rule_set_pass_ids_by_date = []
    
    for rules_date in rule_data:
        #print rules_date['date']
        valid_rule_sets = rules_date['rules']['valid']
        # store for rule_set ids
        # for each valid rule do set intersect then join
        # rule_set of form ('AB1', 'C1', 'E1', 'Auth1')
        for rule_set in valid_rule_sets:
            
            all_pass_ids = get_rule_set_pass_ids(rule_set)
            
            rule_set_pass_ids_by_date.append(\
                {
                 'date': rules_date['date'],
                 'key': ':'.join(rule_set),
                 'ids':all_pass_ids
                 })
            
    return rule_set_pass_ids_by_date

        
def get_databall(rule_groups, timestamp=None, company_cols = COMPANY_COLS):  
    
    possible_rules = get_possible_rules(rule_groups)
    valid_rules_by_date = get_valid_rules_by_date(possible_rules, timestamp, company_cols)
    
    logger.info('VALID RULES BY DATE:')
    for vrs in valid_rules_by_date:
        logger.info('Date: %s, Valid: %d'%(vrs['date'], len(vrs['rules']['valid'])))
        
    _pass_ids_by_date = get_pass_ids_by_date(valid_rules_by_date)
    
    pass_ids_by_date = defaultdict(list)

    for pibd in _pass_ids_by_date:
        pass_ids_by_date[pibd['date']].append(set(pibd['ids']))
    
    d = []
    for k, v in pass_ids_by_date.items():
        d.append({'date': k, 'ids': set.union(*v)})
        
    d.sort(key=itemgetter('date'))
        
    return d
    

def get_aggregate_auth():
    pass_ids_by_date = get_databall(NOAUTH_RULES, pd.Timestamp('2016-11-01'))
    for d in pass_ids_by_date:
        print '%s: pass number %s'%(d['date'], len(d['ids']))   
    
    return pass_ids_by_date


def get_auth_by_company():
    
    res = []
    for c in COMPANY_COLS:
        logger.info('Getting auth-ids for company: ' + c)
        pass_ids = get_databall(NOAUTH_RULES, None, [c])
        for d in pass_ids:
            res.append({'company':c, 'date':d['date'], 'pass':len(d['ids'])})
        
    return res
    

df_rules, df_items = get_dframes()
#df_dummydata = get_dummydata()
df_dummydata = get_rawdata()

#group_items = get_valid_group_items()
#group_ids = get_group_ids()
    
                    
if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    #get_rule_set_pass_ids(('AB1', 'C4', 'E1'))
