import itertools
import pandas as pd
from collections import defaultdict
from operator import itemgetter
import datetime
import numpy as np

import logging
logger = logging.getLogger(__name__)
import config as cf


def memoize(f):
    """ Memoization decorator for functions taking one or more arguments. """
    class memodict(dict):
        def __init__(self, f):
            self.f = f
        def __call__(self, *args):
            return self[args]
        def __missing__(self, key):
            ret = self[key] = self.f(*key)
            return ret
    return memodict(f)

    
def get_possible_rules(rules):
    
    rules = list(itertools.product(*rules))
    
    if cf.FILTER_RULESETS:
        t = set(['AB9', 'AB10', 'AB11', 'C5'])
        new_rules = []
        for r in rules:
            if len(set(r).intersection(t)) < 2:
                new_rules.append(r)   

        return new_rules
    return rules

     
def get_dframes_rules(rule_item_fname=cf.RULE_ITEM_FNAME):
    
    df_rules = pd.read_excel(rule_item_fname, 'Rules')
    df_items = pd.read_excel(rule_item_fname, 'Items')

    df_rules = df_rules.set_index('Rule code')
    # sanitize date-columns with 0 values
    df_rules[df_rules.ix[:, cf.COMPANY_COLS[0]:cf.COMPANY_COLS[-1]].isin([0])] = np.NaN
    df_items[df_items.ix[:, cf.COMPANY_COLS[0]:cf.COMPANY_COLS[-1]].isin([0])] = np.NaN
    
    return df_rules, df_items

    
def get_dframes_data(data_fname=cf.DATA_FNAME):
    df_data = pd.read_csv(data_fname)
    df_data = df_data.set_index('Serial')

    df_data = add_fuzzy_items(df_data)
    # Add weightings
    x = len(df_data.index)
    df_data['norm_weight'] = (x * df_data.INDWGT)/df_data.INDWGT.sum()
    df_data['internet_weight'] = (x * df_data.InternetUse)/df_data.InternetUse.sum()

    return df_data


def add_fuzzy_items(df_data):
    s = set(cf.FUZZY_ITEMS).difference(set(df_data.columns))
    df_data = pd.concat([df_data, pd.DataFrame(columns=s)])
    
    df_fuzzy = pd.read_csv(cf.FUZZY_ITEMS_FNAME)
    df_fuzzy = df_fuzzy.set_index('Code')

    # df_data.apply(fuzzify_row, args=(df_fuzzy), axis=1)
    df_data = df_data.apply(lambda x: fuzzify_row(x, df_fuzzy), axis=1)
    return df_data

    
def fuzzify_row(person, df_fuzzy):
    age = person['RAGE']
    for fi in cf.FUZZY_ITEMS:
        try:
            s = df_fuzzy.loc[fi][age]
            v = float(s.replace('%', ''))/100
            person[fi] = v
        except ValueError:
            # print 'age: %d, fuzzy-item: %s'%(int(age), fi)
            print person
            raise
        

    return person
    

def get_dummydata(fname='dummy_survey.json'):
    
    df_dummydata = pd.read_json(fname, orient='records')
    return df_dummydata

    
def get_rawdata(fname='raw_data.csv'):

    df_rawdata = pd.read_csv(fname)
    return df_rawdata

    
def test_company_cover(df_rule, timestamp, company_cols=cf.COMPANY_COLS):

    companies = {}
    for col in company_cols:
        # Test for missing dates
        if df_rule[df_rule[col].isnull()].empty:
            # if no missing dates
            #print 'first pass with company ' + col
            #print df_rule[col].min()
            #print df_rule
            if df_rule[col].max() <= timestamp:
                companies[col] = True

    return companies
            

def test_rule_set(rule_set, timestamp, company_cols=cf.COMPANY_COLS):
    
    df_rule = df_rules.loc[list(rule_set)]
    #companies = test_company_cover(df, timestamp, company_cols)
    
    companies = []
    for col in company_cols:
        # Test for missing dates
        if df_rule[df_rule[col].isnull()].empty:
            # if no missing dates
            #print 'first pass with company ' + col
            #print df_rule[col].min()
            #print df_rule
            if df_rule[col].max() <= timestamp:
                companies.append(col)
    #logger.info('Rule %s failed'%(str(rule)))
    return companies   
    
    
def get_dates():
    df_companies = df_items.ix[:,cf.COMPANY_COLS[0]:cf.COMPANY_COLS[-1]]
    vals = df_companies.values.flatten()
    vals = list(set(vals))
    vals = [pd.Timestamp(v) for v in vals if type(v) == pd.tslib.Timestamp or type(v) == datetime.datetime]
    # sort and remove first 'NaT' value
    vals.sort()
    return vals    


def get_rules_status_by_date(rules, timestamp, company_cols=cf.COMPANY_COLS):
    """ For timestamped date, get all valid and invalid rules of form 
    AB1:C1:E1.
    """
    res = { 'invalid':[], 'valid':[] }
    
    
    for rule in rules:
        if not test_rule(rule, timestamp, company_cols):
            res['invalid'].append(rule)
        else:
            res['valid'].append(rule)
            
    return {'date': timestamp, 'rules': res}


def get_valid_rules_by_date(rules, cutoff_date, company_cols=cf.COMPANY_COLS):
    """ Get timestamped valid and invalid rules of form AB1:C1:E1 
    rules -> all possible configurations of rule groups A, C, E (Verify)
    """
    key_dates = get_dates()
    if cutoff_date:
        key_dates = [d for d in key_dates if pd.Timestamp(d) < cutoff_date]
        
    rules_data = []
    for d in key_dates:
        timestamp = pd.Timestamp(d)
        rules_data.append(get_rules_status_by_date(rules, timestamp, company_cols))

    return rules_data


def get_rule_item_groups(rule):
    # get slice of rule-items
    #ris = df_rules.loc[rule]['Item group 1':'Item group 4']
    ris = df_rules.loc[rule][cf.ITEM_GROUPS[0]:cf.ITEM_GROUPS[-1]]
    return set(ris[ris.notnull()])
            

    
def get_valid_group_items():
    """ Filter existing set of group items by set available to dummy-data """
    group_items = get_group_items()
    
    dummy_items = [col for col in df_data.columns.tolist() if col in cf.VALID_ITEMS]
    
    valid_group_items = {}
    
    for code, items in group_items.items():
        
        valid_group_items[code] = [item for item in items if item in dummy_items]
        
    return valid_group_items
        

def get_group_ids():
    """ For each group get eligible dummy ids """
    group_ids = {}
    for group, items in group_items.items():
        # ids = df_data[df_data[items].any(1)]['Serial']
        ids = df_data[(df_data[items] > 0).any(axis=1)].index

        group_ids[group] = set(ids)
        
    return group_ids
    

@memoize
def get_rule_set_pass_ids(rule_set):
    pass_sets = []
    # for each rule, e.g. 'AB1', get all pass-ids 
    for rule in rule_set:
        # get all groups for rule, e.g. 'AB1' -> 'C', 'M', 'L' 
        rule_groups = get_rule_groups(rule)
        #valid_items = set()
        #print rule_groups
        all_ids = set()
        # for each rule group, e.g. 'C', get all pass-ids and update set
        # pass-ids derived from data using valid items related to group
        for group in rule_groups:
            try:
                all_ids.update(group_ids[group])
            except KeyError:
                print '%s group has no documents in Items-sheet'%group

        # store the pass-ids for this rule     
        pass_sets.append(all_ids)
        
    logger.info('%s: %s'%(str(rule_set), str([len(ps) for ps in pass_sets])))
    # pass_sets are of form AB1->(3, 7, 16...), C->(2, 4, 5, ...) 
    # user must pass every rule in rule_set so we want to intersect these
    # id-sets
    all_pass_ids = set(df_data.index) # start with all the ids
    for ids in pass_sets:
        all_pass_ids.intersection_update(ids)
                
    logger.info('Number of pass ids: ' + str(len(all_pass_ids)))
    
    return all_pass_ids
    
    
def get_pass_ids_by_date(rule_data):
    """ Given rule_data of form [{'date':.., 'rules':{'invalid':[], 'valid':[]}}]
    return ids passing each rule by date.
    """
    # get rule data, list of valid and invalid by date
    #rule_data = get_rule_data()
    
    rule_set_pass_ids_by_date = []
    
    for rules_date in rule_data:
        #print rules_date['date']
        valid_rule_sets = rules_date['rules']['valid']
        # store for rule_set ids
        # for each valid rule do set intersect then join
        # rule_set of form ('AB1', 'C1', 'E1', 'Verify1')
        for rule_set in valid_rule_sets:
            
            all_pass_ids = get_rule_set_pass_ids(rule_set)
            
            rule_set_pass_ids_by_date.append(\
                {
                 'date': rules_date['date'],
                 'key': ':'.join(rule_set),
                 'ids':all_pass_ids
                 })
            
    return rule_set_pass_ids_by_date

        
def get_databall(rule_groups, timestamp=None, company_cols = cf.COMPANY_COLS):  
    
    possible_rules = get_possible_rules(rule_groups)
    valid_rules_by_date = get_valid_rules_by_date(possible_rules, timestamp, company_cols)
    
    logger.info('VALID RULES BY DATE:')
    for vrs in valid_rules_by_date:
        logger.info('Date: %s, Valid: %d'%(vrs['date'], len(vrs['rules']['valid'])))
        
    _pass_ids_by_date = get_pass_ids_by_date(valid_rules_by_date)
    
    pass_ids_by_date = defaultdict(list)

    for pibd in _pass_ids_by_date:
        pass_ids_by_date[pibd['date']].append(set(pibd['ids']))
    
    d = []
    for k, v in pass_ids_by_date.items():
        d.append({'date': k, 'ids': set.union(*v)})
        
    d.sort(key=itemgetter('date'))
        
    return d
    

def get_aggregate_verify():
    pass_ids_by_date = get_databall(cf.NOVERIFY_RULES, pd.Timestamp('2016-11-01'))
    for d in pass_ids_by_date:
        print '%s: pass number %s'%(d['date'], len(d['ids']))   
    
    return pass_ids_by_date


def get_verify_by_company():
    
    res = []
    for c in cf.COMPANY_COLS:
        logger.info('Getting verify-ids for company: ' + c)
        pass_ids = get_databall(cf.NOVERIFY_RULES, None, [c])
        for d in pass_ids:
            res.append({'company':c, 'date':d['date'], 'pass':len(d['ids'])})
        
    return res
    

df_rules, df_items = get_dframes_rules()
# df_dummydata = get_dummydata()
# df_data = get_rawdata()

    
                    
