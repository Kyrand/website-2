import verifier as vf
import config as cf

def fuzzy_flow():
    dates = vf.get_dates()
    ds = vf.Verifier(dates[1], fuzzy_flag=True, items=cf.ALL_ITEMS)
    df = ds.get_verify_ids()
    print ds.df_data_verify['verify'].sum()

fuzzy_flow()
