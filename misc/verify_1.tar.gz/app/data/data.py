import json
import click
import pandas as pd
import logging
import shutil
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

import verifier as vf
import config as cf


def ts_to_datestring(ts):
    return ts.strftime('%d-%m-%Y') 


def label_group(group, _d):
    d = {}
    #print group
    labels = cf.GROUP_LABELS.get(group)
    if labels:
        for k, v in _d.items():
            k = labels.get(str(int(k)), int(k))
            d[k] = v
        return d
    # sanitize any float keys returned by pivot-table
    for k, v in _d.items():
        d[int(k)] = v
    return d

    
def sanitize_labels(_d):
    d = {}
    
    for k, v in _d.items():
        d[int(k)] = v
    return d

def make_viz_data(df):
    
    data = {}
    for group in cf.DEMOGRAPHIC_GROUPS + ['ALL_VERIFY']:
        
        dfg = df[df['group'] == group]
        dfg = dfg.pivot_table(index='subgroup', columns='date', values='value')
        d = dfg.to_dict()
        # keys are time-stamps
        ks = d.keys()
        ks.sort()
        # data[group] = [dict(date=ts_to_datestring(k), **label_group(group, d[k])) for k in ks] 
        data[group] = [dict(date=ts_to_datestring(k), **sanitize_labels(d[k])) for k in ks] 
    return data
        
    
def make_viz_json(df, json_fname=cf.VIZ_JSON_FNAME):
    
    data = make_viz_data(df)
    json.dump(data, open(json_fname, 'w'))
    shutil.copy2(json_fname, '../static/data')
    return data


def get_demo_data(data_fname=cf.DATA_FNAME):
    logger.setLevel('ERROR')
    df = pd.DataFrame()
    for date in vf.get_dates():
        ds = vf.Verifier(date, fuzzy_flag=True, items=cf.ALL_ITEMS, weights_flag=True, data_fname=data_fname)
        ds.get_verify_ids()
        #print len(ds.pass_ids)
        print 'Date: %s, score: %f'%(str(date), ds.df_data_verify['verify'].sum())
        df = df.append(ds.get_dem_stats())
    df.describe()
    return df


@click.group()
def cli():
    pass
    
    
DEMO_DATA_FNAME = 'data/demo_data.xlsx'
@click.command()
@click.option('--fname', default=DEMO_DATA_FNAME)
def sdata(fname):
    df = get_demo_data()
    df.to_excel(fname)


@click.command()
@click.option('--fname', default=DEMO_DATA_FNAME)
def tojson(fname):
    df = pd.read_excel(fname)
    make_viz_json(df)
    

@click.command()
@click.option('--fname', default=DEMO_DATA_FNAME)
@click.option('--data_fname', '-f', default=cf.DATA_FNAME, multiple=True)
@click.option('--json_fname', default=cf.VIZ_JSON_FNAME)
def full(fname, data_fname, json_fname):
    json_ball = {}
    for fname in data_fname:
        df = get_demo_data(data_fname=fname)
        data = make_viz_data(df)
        json_ball[fname.split('/')[-1].split('.')[0]] = data
        
    with open(json_fname, 'w') as f:
        json.dump(json_ball, f)
        
    shutil.copy2(json_fname, '../static/data')
    #make_viz_json(df, json_fname=json_fname)
    
cli.add_command(sdata)
cli.add_command(tojson)
cli.add_command(full)

    
def main():
    df = get_demo_data()
    make_viz_json(df)


if __name__ == '__main__':
    cli()
    #main()
