## Troubleshooting

- no 'GBDrLic'
- =#REF!+#REF!-(#REF!*#REF!) - DG 1960
- HHtypA
- coding system for demo_stats.csv must be utf-8, otherwise pound signs don't parse.

## software

python data.py full -f data/ONS_aug_oct_employed.csv -f data/ONS_aug_oct_norefused.csv -f data/ONS_aug_oct_over_18.csv 

## final sprint:
- no sheet named Items
- Item Groups should be 'Item Group 1...'
