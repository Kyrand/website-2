import random
import json
import click
import uuid


class RouletteWheel(object):
    """ provide list of weighted opts, e.g. [('foo', 2), ('bar', 1)...
    and use get to generate roullette selection.
    """
    def __init__(self, opts):
        self.opts = opts
        self.total = sum([opt[1] for opt in opts])
        # print 'Total = ' + str(self.total)
        
    def get(self):
        cum = 0
        stop = random.random() * self.total
        for opt in self.opts:
            cum += opt[1]
            if cum > stop:
                return opt[0]

                
def create_column_generators():
    RW = RouletteWheel
    
    _column_gens = [
        {'name': 'age', 'gen': RW((('1624', 1), ('2544', 3), ('4554', 2), ('5564', 1), ('6574', 1), ('7500', 0.5)))},
        {'name': 'locale', 'gen': RW((('urban', 8), ('rural', 2)))},
        {'name': 'gender', 'gen': RW((('male', 1), ('female', 1)))},
        {'name': 'UKPPort', 'gen': RW(((1, 79), (0, 21)))},
        {'name': 'UKDrLic', 'gen': RW(((1, 74), (0, 26)))},
        {'name': 'ROIPPort', 'gen': RW(((1, 0), (0, 100)))},
        {'name': 'EUPPort', 'gen': RW(((1, 6), (0, 94)))},
        {'name': 'NonEUPP', 'gen': RW(((1, 4), (0, 96)))},
        {'name': 'UKBiP', 'gen': RW(((1, 1), (0, 99)))},
        {'name': 'UKASC', 'gen': RW(((1, 0), (0, 100)))},
        {'name': 'UKBAc', 'gen': RW(((1, 94), (0, 6)))},
        {'name': 'UKCCard', 'gen': RW(((1, 54), (0, 46)))},
        {'name': 'UKLoan', 'gen': RW(((1, 14), (0, 86)))},
        {'name': 'UKMort', 'gen': RW(((1, 27), (0, 73)))},
        {'name': 'SPhone', 'gen': RW(((1, 54), (0, 46)))},
        ]
        
    return _column_gens
        
column_gens = create_column_generators()

 
def create_respondent(id=None):
    global column_gens

    # random ID if not provided
    if id is None:
        id = str(uuid.uuid4())
        
    resp = {'Serial': id}
    for c in column_gens:
        resp[c['name']] = c['gen'].get()

    return resp


def create_dummy_survey_data(size=2000):
    """ Create dummy survey data of size <size> """
    
    data = []
    for i, s in enumerate(range(size)):
        data.append(create_respondent(i))
        
    return data
    
    
@click.command()
@click.option('--fname', default='dummy_survey.json')
@click.option('--size', default=2000)
def create_dummy_survey(fname, size):
    data = create_dummy_survey_data(size)
    json.dump(data, open(fname, 'w'))
    
    
if __name__ == '__main__':
    create_dummy_survey()
